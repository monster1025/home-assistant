"""HACS Updater."""
from . import Hacs


class HacsUpdate(Hacs):
    """Update class."""
